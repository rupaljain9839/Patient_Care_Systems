"""IPCMS theme v3 — teal/mint healthcare-app palette (sky-blue theme replaced).
Injected once via apply_theme() in app.py. No external CSS file — everything
lives in this one Python string so there is no file-path to break.
"""
import streamlit as st

_CSS = """
<style>
:root {
    --ipcms-teal-dark: #164a7a;
    --ipcms-teal: #1d6fb8;
    --ipcms-teal-light: #3b8fd4;
    --ipcms-mint: #dbeafe;
    --ipcms-mint-soft: #eef5ff;
    --ipcms-page-bg: #eef2f8;
    --ipcms-card-bg: #ffffff;
    --ipcms-text-dark: #10233a;
    --ipcms-text-muted: #6b7f96;
}

.stApp {
    background-color: var(--ipcms-page-bg);
}

/* ---------- Sidebar ---------- */
section[data-testid="stSidebar"] {
    background: linear-gradient(180deg, var(--ipcms-teal) 0%, var(--ipcms-teal-dark) 100%);
}
section[data-testid="stSidebar"] * {
    color: #e3f8f5 !important;
}
section[data-testid="stSidebar"] h3,
section[data-testid="stSidebar"] h4 {
    color: #ffffff !important;
}

section[data-testid="stSidebar"] .stButton > button {
    background: rgba(255, 255, 255, 0.10);
    border: 1px solid rgba(255, 255, 255, 0.16);
    color: #e3f8f5 !important;
    border-radius: 10px;
    text-align: left;
    justify-content: flex-start;
    padding: 0.6rem 1rem;
    font-weight: 600;
    margin-bottom: 0.35rem;
    width: 100%;
}
section[data-testid="stSidebar"] .stButton > button:hover {
    background: rgba(255, 255, 255, 0.2);
    transform: none;
    box-shadow: none;
}

.ipcms-brand-box {
    background: rgba(255, 255, 255, 0.10);
    border-radius: 12px;
    padding: 0.9rem 1rem;
    margin-bottom: 1.2rem;
    display: flex;
    align-items: center;
    gap: 0.7rem;
}
.ipcms-brand-box .icon {
    background: white;
    color: var(--ipcms-teal-dark);
    border-radius: 8px;
    width: 34px;
    height: 34px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 800;
    flex-shrink: 0;
}
.ipcms-brand-box .name {
    font-weight: 800;
    font-size: 0.95rem;
    color: white !important;
    line-height: 1.1;
}
.ipcms-brand-box .tagline {
    font-size: 0.68rem;
    color: #cdece7 !important;
    line-height: 1.2;
}

.ipcms-user-box {
    background: rgba(255, 255, 255, 0.08);
    border-radius: 10px;
    padding: 0.7rem 0.9rem;
    margin-bottom: 1.1rem;
}
.ipcms-user-box .name {
    font-weight: 700;
    color: white !important;
    font-size: 0.95rem;
}
.ipcms-user-box .role {
    font-size: 0.75rem;
    color: #cdece7 !important;
}

/* ---------- Main content ---------- */
h1, h2, h3 {
    color: var(--ipcms-text-dark);
}

/* Greeting header — "Good Morning, Mr. X" style */
.ipcms-greeting-card {
    background: var(--ipcms-card-bg);
    border-radius: 18px;
    padding: 1.3rem 1.6rem;
    box-shadow: 0 2px 14px rgba(22, 74, 122, 0.10);
    margin-bottom: 1.2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.ipcms-greeting-card .greeting {
    font-size: 0.95rem;
    font-weight: 700;
    color: var(--ipcms-teal);
    margin-bottom: 0.1rem;
}
.ipcms-greeting-card .name {
    font-size: 1.35rem;
    font-weight: 800;
    color: var(--ipcms-text-dark);
}
.ipcms-greeting-card .sub {
    font-size: 0.9rem;
    color: var(--ipcms-teal-dark);
    font-weight: 600;
    margin-top: 0.15rem;
}
.ipcms-greeting-bell {
    background: var(--ipcms-mint);
    border-radius: 50%;
    width: 42px;
    height: 42px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.2rem;
    flex-shrink: 0;
}

/* Old page-header card kept for admin/doctor portals */
.ipcms-header-card {
    background: var(--ipcms-card-bg);
    border-radius: 16px;
    padding: 1.3rem 1.6rem;
    box-shadow: 0 2px 12px rgba(22, 74, 122, 0.10);
    margin-bottom: 1.2rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.ipcms-header-card .title {
    font-size: 1.5rem;
    font-weight: 800;
    color: var(--ipcms-text-dark);
}
.ipcms-header-card .subtitle {
    color: var(--ipcms-text-muted);
    font-size: 0.9rem;
    margin-top: 0.15rem;
}
.ipcms-header-badge {
    background: var(--ipcms-teal);
    color: white;
    border-radius: 10px;
    padding: 0.45rem 0.9rem;
    font-weight: 700;
    font-size: 0.85rem;
}

/* Big hero action card — "Book an Appointment" */
.ipcms-hero-card {
    background: var(--ipcms-card-bg);
    border-radius: 20px;
    padding: 1.5rem 1.6rem;
    box-shadow: 0 4px 18px rgba(22, 74, 122, 0.10);
    margin-bottom: 1rem;
}
.ipcms-hero-card .hero-title {
    font-size: 1.15rem;
    font-weight: 800;
    color: var(--ipcms-text-dark);
    display: flex;
    align-items: center;
    justify-content: space-between;
}
.ipcms-hero-icon {
    background: var(--ipcms-mint);
    border-radius: 12px;
    width: 44px;
    height: 44px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.3rem;
}

/* Small tiles — "Book Lab Tests" / "Instant Consult" */
.ipcms-tile {
    background: var(--ipcms-card-bg);
    border-radius: 16px;
    padding: 1.1rem 1.2rem;
    box-shadow: 0 3px 14px rgba(22, 74, 122, 0.08);
    text-align: left;
    height: 100%;
}
.ipcms-tile .tile-icon {
    background: var(--ipcms-mint);
    border-radius: 12px;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.15rem;
    margin-bottom: 0.6rem;
}
.ipcms-tile .tile-label {
    font-weight: 800;
    color: var(--ipcms-text-dark);
    font-size: 0.95rem;
    line-height: 1.2;
}

/* Home healthcare services panel */
.ipcms-services-panel {
    background: linear-gradient(135deg, var(--ipcms-mint-soft) 0%, var(--ipcms-mint) 100%);
    border-radius: 18px;
    padding: 1.2rem 1.4rem;
    margin-bottom: 1rem;
}
.ipcms-services-panel .panel-title {
    font-weight: 800;
    color: var(--ipcms-teal-dark);
    font-size: 1rem;
    margin-bottom: 0.9rem;
}
.ipcms-service-icon {
    background: white;
    border-radius: 14px;
    width: 56px;
    height: 56px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 1.5rem;
    margin: 0 auto 0.5rem auto;
    box-shadow: 0 2px 8px rgba(22, 74, 122, 0.10);
}
.ipcms-service-label {
    text-align: center;
    font-size: 0.8rem;
    font-weight: 700;
    color: var(--ipcms-teal-dark);
}

/* Doctor search result row */
.ipcms-doctor-row {
    background: var(--ipcms-mint-soft);
    border-radius: 14px;
    padding: 0.8rem 1rem;
    margin-top: 0.6rem;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
.ipcms-doctor-row .dname {
    font-weight: 800;
    color: var(--ipcms-text-dark);
    font-size: 0.95rem;
}
.ipcms-doctor-row .dmeta {
    font-size: 0.8rem;
    color: var(--ipcms-text-muted);
}
.ipcms-doctor-row .dbadge {
    background: var(--ipcms-teal);
    color: white;
    font-weight: 700;
    font-size: 0.75rem;
    border-radius: 8px;
    padding: 0.3rem 0.7rem;
    white-space: nowrap;
}

/* Generic white content panel */
.ipcms-panel {
    background: var(--ipcms-card-bg);
    border-radius: 16px;
    padding: 1.2rem 1.4rem;
    box-shadow: 0 2px 12px rgba(22, 74, 122, 0.10);
    margin-bottom: 1rem;
}
.ipcms-panel .panel-label {
    font-size: 0.85rem;
    color: var(--ipcms-text-muted);
    font-weight: 600;
    margin-bottom: 0.4rem;
}
.ipcms-panel .panel-empty {
    color: #8ea3ba;
    font-size: 0.9rem;
}
.ipcms-panel .panel-title {
    font-size: 1.25rem;
    font-weight: 800;
    color: var(--ipcms-text-dark);
    margin-top: 0.2rem;
}
.ipcms-panel .mini-stats {
    display: flex;
    gap: 2rem;
    margin-top: 1rem;
}
.ipcms-panel .mini-stats .k {
    font-size: 0.78rem;
    color: var(--ipcms-text-muted);
    font-weight: 600;
}
.ipcms-panel .mini-stats .v {
    font-size: 1.3rem;
    font-weight: 800;
    color: var(--ipcms-teal);
}

/* Buttons in main content */
.stButton > button {
    background: linear-gradient(135deg, var(--ipcms-teal) 0%, var(--ipcms-teal-light) 100%);
    color: white;
    border: none;
    border-radius: 10px;
    padding: 0.5rem 1.2rem;
    font-weight: 600;
}
.stButton > button:hover {
    box-shadow: 0 6px 16px rgba(29, 111, 184, 0.3);
    color: white;
}
.stButton > button:disabled {
    background: #d4e6e4;
    color: #8ea3ba;
}

/* Text input styling (search boxes etc.) */
.stTextInput > div > div > input {
    border-radius: 10px;
}

/* Tabs */
.stTabs [data-baseweb="tab"] {
    font-weight: 600;
    color: var(--ipcms-text-dark);
}
.stTabs [aria-selected="true"] {
    color: var(--ipcms-teal) !important;
    border-bottom-color: var(--ipcms-teal) !important;
}

[data-testid="stMetric"] {
    background: white;
    border-radius: 14px;
    padding: 1rem 1.2rem;
    box-shadow: 0 2px 10px rgba(22, 74, 122, 0.08);
}

/* Gradient/light-fill stat card (views/components.py render_stat_card) */
.ipcms-stat-card {
    border-radius: 16px;
    padding: 1.1rem 1.3rem;
    min-height: 100px;
    box-shadow: 0 4px 16px rgba(22, 74, 122, 0.10);
}
.ipcms-stat-card .label {
    font-size: 0.85rem;
    font-weight: 700;
    color: var(--ipcms-teal-dark);
}
.ipcms-stat-card .value {
    font-size: 2.1rem;
    font-weight: 800;
    margin-top: 0.2rem;
    color: var(--ipcms-text-dark);
}

/* Live vitals card */
.ipcms-vitals-wrap {
    background: linear-gradient(180deg, #eef5ff 0%, #dbeafe 100%);
    border-radius: 20px;
    padding: 1.8rem;
    box-shadow: 0 4px 20px rgba(22, 74, 122, 0.10);
}
.ipcms-vitals-title {
    letter-spacing: 0.12em;
    font-size: 0.8rem;
    font-weight: 800;
    color: var(--ipcms-teal);
    margin-bottom: 0.8rem;
}
.ipcms-vitals-pill {
    background: white;
    border-radius: 14px;
    padding: 0.7rem 1rem;
    box-shadow: 0 3px 10px rgba(22, 74, 122, 0.08);
    margin-bottom: 0.7rem;
}
.ipcms-vitals-pill .k {
    font-size: 0.75rem;
    color: var(--ipcms-text-muted);
    font-weight: 600;
}
.ipcms-vitals-pill .v {
    font-size: 1.25rem;
    font-weight: 800;
    color: var(--ipcms-text-dark);
}
</style>
"""


def apply_theme():
    st.markdown(_CSS, unsafe_allow_html=True)