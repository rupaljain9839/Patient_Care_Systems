"""Tools SmartCare AI can call, scoped per role via closures over the current user.
Every tool that touches 'my'/'own' data is bound to the logged-in user's id — the model
can never override whose appointments it's acting on for those. Tools that legitimately
need to reference OTHER people (a doctor by name, a patient by name for admin booking)
take that as an explicit parameter, resolved by fuzzy name match.
"""
from datetime import datetime as _dt

from langchain_core.tools import tool

from services.doctor_service import list_doctors as _list_doctors_raw
from services.appointment_service import (
    get_available_slots,
    get_slot_summary,
    book_appointment as _book_appointment,
    get_patient_appointments,
    cancel_appointment as _cancel_appointment,
    get_doctor_appointments,
    get_doctor_stats,
    get_all_appointments,
    get_admin_appointment_overview,
    get_busiest_doctors,
    get_staffing_gaps,
)
from services.health_service import get_latest_vitals, search_patients
from ai.knowledge_base import retrieve_context


def _parse_date(date_str: str):
    date_str = (date_str or "").strip()
    for fmt in ("%Y-%m-%d", "%d-%m-%Y", "%d/%m/%Y"):
        try:
            return _dt.strptime(date_str, fmt).date()
        except ValueError:
            continue
    return None


def _parse_time(time_str: str):
    time_str = (time_str or "").strip()
    for fmt in ("%H:%M", "%I:%M %p", "%I%p", "%H"):
        try:
            return _dt.strptime(time_str, fmt).time()
        except ValueError:
            continue
    return None


def _normalize_name(s: str) -> str:
    s = (s or "").lower().strip()
    for prefix in ("dr. ", "dr.", "dr ", "doctor "):
        if s.startswith(prefix):
            s = s[len(prefix):].strip()
    return s


def _resolve_doctor(name: str):
    """Returns (doctor_dict, error_message) — exactly one of which is None.
    Handles 'Dr.' prefixes and partial/out-of-order name matches, since patients
    and doctors don't reliably type full names in database order."""
    query = _normalize_name(name)
    all_docs = _list_doctors_raw()

    matches = [d for d in all_docs if query in _normalize_name(d["full_name"]) or _normalize_name(d["full_name"]) in query]

    if not matches:
        query_tokens = set(query.split())
        matches = [
            d for d in all_docs
            if query_tokens & set(_normalize_name(d["full_name"]).split())
        ]

    if not matches:
        return None, f"No doctor found matching '{name}'."
    if len(matches) > 1:
        options = ", ".join(f"Dr. {d['full_name']} ({d['specialty']})" for d in matches)
        return None, f"Multiple doctors match '{name}': {options}. Please ask which one they mean."
    return matches[0], None


def _search_reference_tool():
    @tool
    def search_health_reference(query: str) -> str:
        """Search general cardiac health reference material for background info on a topic
        like blood pressure, heart rate, troponin, ejection fraction, ECG terms, pulse
        oximetry, lifestyle, or emergency symptoms."""
        chunks = retrieve_context(query, k=3)
        return "\n\n".join(chunks) if chunks else "No reference material found for that."

    return search_health_reference


def _list_doctors_tool():
    @tool
    def list_doctors(specialty: str = "", sort_by_fee: str = "") -> str:
        """List doctors in the hospital. Optionally filter by specialty name (e.g.
        'Cardiology') and sort by fee: pass sort_by_fee='desc' to find the highest-fee
        doctors first, or 'asc' for lowest-fee first."""
        sort = "fee_desc" if sort_by_fee == "desc" else ("fee_asc" if sort_by_fee == "asc" else "name")
        docs = _list_doctors_raw(sort=sort)
        if specialty:
            docs = [d for d in docs if specialty.lower() in d["specialty"].lower()]
        if not docs:
            return "No doctors found matching that."
        return "\n".join(
            f"Dr. {d['full_name']} — {d['specialty']} — ₹{d['consultation_fee']:.0f} — {d['experience_years']} yrs experience"
            for d in docs
        )

    return list_doctors


def _check_slots_tool():
    @tool
    def check_available_slots(doctor_name: str, date: str) -> str:
        """Check available appointment slots for a named doctor on a given date
        (format: YYYY-MM-DD)."""
        target_date = _parse_date(date)
        if not target_date:
            return f"Couldn't understand the date '{date}'. Please ask for a clearer date in YYYY-MM-DD format."
        doctor, err = _resolve_doctor(doctor_name)
        if err:
            return err
        total, free = get_slot_summary(doctor["id"], target_date)
        if total == 0:
            return f"Dr. {doctor['full_name']} has no availability set for {target_date}."
        slots = get_available_slots(doctor["id"], target_date)
        if not slots:
            return f"Dr. {doctor['full_name']} is fully booked on {target_date}."
        return f"Dr. {doctor['full_name']} has {free} of {total} slots free on {target_date}: " + ", ".join(
            t.strftime("%H:%M") for t in slots
        )

    return check_available_slots


# ---------------------------------------------------------------- Patient tools

def get_patient_tools(user: dict):
    patient_id = user["id"]

    @tool
    def get_health_condition() -> str:
        """Get this patient's own most recent recorded vitals and diagnosis."""
        vitals = get_latest_vitals(patient_id)
        if not vitals:
            return "No vitals have been recorded for this patient yet."
        parts = []
        if vitals.get("diagnosis"):
            parts.append(f"Diagnosis: {vitals['diagnosis']}")
        if vitals.get("blood_pressure"):
            parts.append(f"Blood pressure: {vitals['blood_pressure']} mmHg")
        if vitals.get("heart_rate") is not None:
            parts.append(f"Heart rate: {vitals['heart_rate']} bpm")
        if vitals.get("troponin") is not None:
            parts.append(f"Troponin: {vitals['troponin']} ng/mL")
        if vitals.get("ejection_fraction") is not None:
            parts.append(f"Ejection fraction: {vitals['ejection_fraction']}%")
        if vitals.get("cardiac_output") is not None:
            parts.append(f"Cardiac output: {vitals['cardiac_output']} L/min")
        if vitals.get("pulse_oximetry") is not None:
            parts.append(f"Pulse oximetry: {vitals['pulse_oximetry']}%")
        if vitals.get("ecg_note"):
            parts.append(f"ECG note: {vitals['ecg_note']}")
        return "\n".join(parts) if parts else "Vitals recorded but no values on file."

    @tool
    def list_upcoming_appointments() -> str:
        """List this patient's own upcoming appointments."""
        appts = get_patient_appointments(patient_id, upcoming_only=True)
        if not appts:
            return "No upcoming appointments."
        return "\n".join(
            f"#{a['id']}: {a['scheduled_date']} {a['start_time']} with Dr. {a['doctor_name']} ({a['specialty']}) — {a['status']}"
            for a in appts
        )

    @tool
    def get_appointment_counts() -> str:
        """Get counts of this patient's completed, pending (booked), and cancelled appointments."""
        appts = get_patient_appointments(patient_id, upcoming_only=False)
        completed = len([a for a in appts if a["status"] == "completed"])
        pending = len([a for a in appts if a["status"] == "booked"])
        cancelled = len([a for a in appts if a["status"] == "cancelled"])
        return f"Completed: {completed}, Pending (booked): {pending}, Cancelled: {cancelled}"

    @tool
    def book_appointment(doctor_name: str, date: str, time: str, reason: str = "") -> str:
        """Book an appointment for this patient with a named doctor, on a date
        (YYYY-MM-DD) and time (HH:MM, 24-hour). Always confirm the doctor, date, and
        time with the patient before calling this — do not guess any of them."""
        target_date = _parse_date(date)
        target_time = _parse_time(time)
        if not target_date:
            return f"Couldn't understand the date '{date}'. Ask the patient for a clearer date (YYYY-MM-DD)."
        if not target_time:
            return f"Couldn't understand the time '{time}'. Ask the patient for a clearer time (HH:MM)."
        doctor, err = _resolve_doctor(doctor_name)
        if err:
            return err
        result = _book_appointment(patient_id, doctor["id"], target_date, target_time, reason)
        return result.message

    @tool
    def cancel_appointment(doctor_name: str = "", date: str = "", time: str = "") -> str:
        """Cancel one of this patient's own upcoming appointments. Provide whichever of
        doctor_name, date (YYYY-MM-DD), or time (HH:MM) the patient specified to narrow
        it down. If multiple appointments still match, list them and ask the patient to
        clarify instead of guessing which one to cancel."""
        appts = [a for a in get_patient_appointments(patient_id, upcoming_only=True) if a["status"] == "booked"]
        if doctor_name:
            appts = [a for a in appts if doctor_name.lower() in a["doctor_name"].lower()]
        if date:
            d = _parse_date(date)
            if d:
                appts = [a for a in appts if a["scheduled_date"] == d]
        if time:
            t = _parse_time(time)
            if t:
                appts = [a for a in appts if a["start_time"] == t]
        if not appts:
            return "No matching upcoming appointment found to cancel."
        if len(appts) > 1:
            options = "; ".join(f"#{a['id']} with Dr. {a['doctor_name']} on {a['scheduled_date']} at {a['start_time']}" for a in appts)
            return f"Multiple matching appointments found — ask the patient to specify further: {options}"
        result = _cancel_appointment(appts[0]["id"], patient_id)
        return result.message

    return [
        _list_doctors_tool(),
        _check_slots_tool(),
        get_health_condition,
        list_upcoming_appointments,
        get_appointment_counts,
        book_appointment,
        cancel_appointment,
        _search_reference_tool(),
    ]


# ---------------------------------------------------------------- Doctor tools

def get_doctor_tools(user: dict):
    doctor_user_id = user["id"]

    @tool
    def list_upcoming_appointments() -> str:
        """List this doctor's own upcoming appointments."""
        appts = get_doctor_appointments(doctor_user_id, upcoming_only=True)
        if not appts:
            return "No upcoming appointments."
        return "\n".join(
            f"#{a['id']}: {a['scheduled_date']} {a['start_time']} with {a['patient_name']} — {a['status']}"
            for a in appts
        )

    @tool
    def get_appointment_counts() -> str:
        """Get this doctor's own appointment stats: today's count, total upcoming,
        completed (all-time), and unique patients."""
        stats = get_doctor_stats(doctor_user_id)
        return (
            f"Today: {stats['today']}, Upcoming: {stats['upcoming']}, "
            f"Completed: {stats['completed']}, Unique patients: {stats['unique_patients']}"
        )

    @tool
    def cancel_appointment(patient_name: str = "", date: str = "", time: str = "") -> str:
        """Cancel one of THIS doctor's own upcoming appointments. Provide whichever of
        patient_name, date (YYYY-MM-DD), or time (HH:MM) was specified to narrow it
        down. If multiple appointments still match, list them and ask which one instead
        of guessing."""
        appts = [a for a in get_doctor_appointments(doctor_user_id, upcoming_only=True) if a["status"] == "booked"]
        if patient_name:
            appts = [a for a in appts if patient_name.lower() in a["patient_name"].lower()]
        if date:
            d = _parse_date(date)
            if d:
                appts = [a for a in appts if a["scheduled_date"] == d]
        if time:
            t = _parse_time(time)
            if t:
                appts = [a for a in appts if a["start_time"] == t]
        if not appts:
            return "No matching upcoming appointment found to cancel."
        if len(appts) > 1:
            options = "; ".join(f"#{a['id']} with {a['patient_name']} on {a['scheduled_date']} at {a['start_time']}" for a in appts)
            return f"Multiple matching appointments found — ask which one: {options}"
        result = _cancel_appointment(appts[0]["id"])
        return result.message

    return [
        _list_doctors_tool(),
        list_upcoming_appointments,
        get_appointment_counts,
        cancel_appointment,
        _search_reference_tool(),
    ]


# ---------------------------------------------------------------- Admin tools

def get_admin_tools(user: dict):
    @tool
    def list_upcoming_appointments() -> str:
        """List all upcoming appointments system-wide."""
        from datetime import date as _date

        appts = get_all_appointments(status_filter="Booked", start_date=_date.today())
        if not appts:
            return "No upcoming appointments."
        return "\n".join(
            f"#{a['id']}: {a['scheduled_date']} {a['start_time']} — {a['patient_name']} with Dr. {a['doctor_name']} ({a['specialty']})"
            for a in appts[:30]
        )

    @tool
    def get_appointment_counts() -> str:
        """Get system-wide appointment counts: total, upcoming, and breakdown by status."""
        overview = get_admin_appointment_overview()
        status_line = ", ".join(f"{k}: {v}" for k, v in overview["by_status"].items()) or "none yet"
        return f"Total: {overview['total']}, Upcoming: {overview['upcoming']}, By status: {status_line}"

    @tool
    def get_system_overview() -> str:
        """Get system-wide stats: total patients, total doctors, busiest doctors, and
        specialties with no bookable doctor (staffing gaps)."""
        from core.database import session_scope
        from models.models import User

        with session_scope() as session:
            total_patients = session.query(User).filter(User.role == "patient").count()
            total_doctors = session.query(User).filter(User.role == "doctor").count()
        busiest = get_busiest_doctors(limit=5)
        gaps = get_staffing_gaps()
        busiest_line = ", ".join(f"{name} ({count})" for name, count in busiest) or "no upcoming appointments yet"
        gaps_line = ", ".join(gaps) if gaps else "none — full coverage"
        return (
            f"Total patients: {total_patients}, Total doctors: {total_doctors}\n"
            f"Busiest doctors (upcoming): {busiest_line}\n"
            f"Specialties with no bookable doctor: {gaps_line}"
        )

    @tool
    def book_appointment_for_patient(patient_name: str, doctor_name: str, date: str, time: str, reason: str = "") -> str:
        """Book an appointment on behalf of a named patient, with a named doctor, on a
        date (YYYY-MM-DD) and time (HH:MM, 24-hour). Always confirm patient, doctor,
        date, and time before calling this — do not guess any of them."""
        target_date = _parse_date(date)
        target_time = _parse_time(time)
        if not target_date:
            return f"Couldn't understand the date '{date}'. Ask for a clearer date (YYYY-MM-DD)."
        if not target_time:
            return f"Couldn't understand the time '{time}'. Ask for a clearer time (HH:MM)."

        patients = search_patients(patient_name, limit=5)
        if not patients:
            return f"No patient found matching '{patient_name}'."
        if len(patients) > 1:
            options = ", ".join(f"{p['full_name']} ({p['email']})" for p in patients)
            return f"Multiple patients match '{patient_name}': {options}. Please ask which one."

        doctor, err = _resolve_doctor(doctor_name)
        if err:
            return err

        result = _book_appointment(patients[0]["id"], doctor["id"], target_date, target_time, reason)
        return result.message

    @tool
    def cancel_appointment(patient_name: str = "", doctor_name: str = "", date: str = "", time: str = "") -> str:
        """Cancel any upcoming appointment system-wide. Provide whichever of
        patient_name, doctor_name, date (YYYY-MM-DD), or time (HH:MM) was specified to
        narrow it down. If multiple appointments still match, list them and ask which
        one instead of guessing."""
        from datetime import date as _date

        appts = get_all_appointments(status_filter="Booked", start_date=_date.today())
        if patient_name:
            appts = [a for a in appts if patient_name.lower() in a["patient_name"].lower()]
        if doctor_name:
            appts = [a for a in appts if doctor_name.lower() in a["doctor_name"].lower()]
        if date:
            d = _parse_date(date)
            if d:
                appts = [a for a in appts if a["scheduled_date"] == d]
        if time:
            t = _parse_time(time)
            if t:
                appts = [a for a in appts if a["start_time"] == t]
        if not appts:
            return "No matching upcoming appointment found to cancel."
        if len(appts) > 1:
            options = "; ".join(
                f"#{a['id']} {a['patient_name']} with Dr. {a['doctor_name']} on {a['scheduled_date']} at {a['start_time']}"
                for a in appts
            )
            return f"Multiple matching appointments found — ask which one: {options}"
        result = _cancel_appointment(appts[0]["id"])
        return result.message

    return [
        _list_doctors_tool(),
        list_upcoming_appointments,
        get_appointment_counts,
        get_system_overview,
        book_appointment_for_patient,
        cancel_appointment,
        _search_reference_tool(),
    ]