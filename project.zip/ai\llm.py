"""Groq LLM access via LangChain, per the model configured in .env (GROQ_MODEL)."""
from langchain_groq import ChatGroq
from langchain_core.messages import SystemMessage, HumanMessage, AIMessage, ToolMessage

from core.config import settings


def get_llm():
    if not settings.llm_configured:
        raise RuntimeError(
            "GROQ_API_KEY is not set in .env — SmartCare AI needs it to work. "
            "Get a free key at https://console.groq.com and add it to .env."
        )
    return ChatGroq(
        model=settings.groq_model,
        api_key=settings.groq_api_key,
        temperature=settings.llm_temperature,
    )


def _to_langchain_messages(system_prompt: str, history: list, user_message: str):
    messages = [SystemMessage(content=system_prompt)]
    for turn in history:
        if turn["role"] == "user":
            messages.append(HumanMessage(content=turn["content"]))
        else:
            messages.append(AIMessage(content=turn["content"]))
    messages.append(HumanMessage(content=user_message))
    return messages


def chat_completion(system_prompt: str, history: list, user_message: str) -> str:
    """history: list of {"role": "user"|"assistant", "content": str}, oldest first."""
    llm = get_llm()
    messages = _to_langchain_messages(system_prompt, history, user_message)
    response = llm.invoke(messages)
    return response.content


def run_agent(system_prompt: str, history: list, user_message: str, tools: list, max_iterations: int = 6) -> str:
    """Runs a tool-calling loop: the model can call any of `tools`, see the result, and
    either call more tools or produce a final text answer. Stops early with a fallback
    message if it doesn't converge within max_iterations, so a confused model can never
    loop forever."""
    llm = get_llm().bind_tools(tools)
    messages = _to_langchain_messages(system_prompt, history, user_message)
    tool_map = {t.name: t for t in tools}

    for _ in range(max_iterations):
        response = llm.invoke(messages)
        if not getattr(response, "tool_calls", None):
            return response.content

        messages.append(response)
        for call in response.tool_calls:
            tool_obj = tool_map.get(call["name"])
            if tool_obj is None:
                result = f"Unknown tool: {call['name']}"
            else:
                try:
                    result = tool_obj.invoke(call["args"])
                except Exception as e:
                    result = f"Error running {call['name']}: {e}"
            messages.append(ToolMessage(content=str(result), tool_call_id=call["id"]))

    return "I wasn't able to finish that after several steps — could you rephrase your request with a bit more detail?"